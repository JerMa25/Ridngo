package com.yowyob.rideandgo.infrastructure.adapters.outbound.external.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;
import org.springframework.web.service.annotation.PostExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.List;

/**
 * Client HTTP vers YowYob Pay (yy-pay).
 * Base URL: https://kernel-core.yowyob.com/pay
 * Headers injectés: X-Client-Id, X-Api-Key, X-Tenant-Id (kernelAuthFilter)
 * Authorization: Bearer (addBearerToken)
 *
 * Routes conformes à la spec YowYob Payment BFF.
 */
@HttpExchange("")
public interface PaymentApiClient {

        // ─── Wallets ──────────────────────────────────────────────────────────────

        /** POST /api/payments/wallets — créer un wallet pour un owner */
        @PostExchange("/api/payments/wallets")
        Mono<WalletResponse> createWallet(@RequestBody CreateWalletRequest request);

        /**
         * GET /api/payments/wallets/owner/{ownerId} — récupérer le wallet d'un owner
         */
        @GetExchange("/api/payments/wallets/owner/{ownerId}")
        Mono<WalletResponse> getWalletByOwnerId(@PathVariable("ownerId") String ownerId);

        /** GET /api/payments/wallets/{walletId} — récupérer un wallet par son ID */
        @GetExchange("/api/payments/wallets/{walletId}")
        Mono<WalletResponse> getWalletById(@PathVariable("walletId") String walletId);

        // ─── Paiement ─────────────────────────────────────────────────────────────

        /** POST /api/payments/wallets/{walletId}/pay — débiter le wallet */
        @PostExchange("/api/payments/wallets/{walletId}/pay")
        Mono<PaymentResponse> payFromWallet(
                        @PathVariable("walletId") String walletId,
                        @RequestBody PaymentRequest request);

        // ─── Transactions ─────────────────────────────────────────────────────────

        /**
         * GET /api/payments/wallets/{walletId}/transactions — historique des
         * transactions
         */
        @GetExchange("/api/payments/wallets/{walletId}/transactions")
        Flux<TransactionResponse> getTransactions(@PathVariable("walletId") String walletId);

        /**
         * POST /api/payments/wallets/{walletId}/recharge — démarrer une recharge via
         * provider (MYCOOLPAY)
         */
        @PostExchange("/api/payments/wallets/{walletId}/recharge")
        Mono<RechargeOrderResponse> rechargeWallet(
                        @PathVariable("walletId") String walletId,
                        @RequestBody RechargeRequest request);

        /**
         * GET /api/payments/wallets/{walletId}/recharge-orders — historique des
         * recharges d'un wallet
         */
        @GetExchange("/api/payments/wallets/{walletId}/recharge-orders")
        Flux<RechargeOrderResponse> getRechargeOrders(@PathVariable("walletId") String walletId);

        /**
         * GET /api/payments/wallets/recharge-orders/{orderId} — détail d'une recharge
         */
        @GetExchange("/api/payments/wallets/recharge-orders/{orderId}")
        Mono<RechargeOrderResponse> getRechargeOrder(@PathVariable("orderId") String orderId);

        /**
         * POST /api/payments/wallets/recharge-orders/{orderId}/refresh — confirmer le
         * statut provider + créditer si succès
         */
        @PostExchange("/api/payments/wallets/recharge-orders/{orderId}/refresh")
        Mono<RechargeOrderResponse> refreshRechargeOrder(@PathVariable("orderId") String orderId);

        /**
         * GET /api/payments/wallets/{walletId}/can-operate?amount= — vérifier si
         * opération possible
         */
        @GetExchange("/api/payments/wallets/{walletId}/can-operate")
        Mono<CanOperateResponse> canOperate(
                        @PathVariable("walletId") String walletId,
                        @org.springframework.web.bind.annotation.RequestParam("amount") double amount);

        // ─── Orders ───────────────────────────────────────────────────────────────

        /** GET /api/payments/orders — historique des ordres de paiement */
        @GetExchange("/api/payments/orders")
        Flux<OrderResponse> listOrders();

        /**
         * POST /api/payments/orders/{id}/refresh — rafraîchir le statut d'un ordre
         * auprès du provider
         */
        @PostExchange("/api/payments/orders/{id}/refresh")
        Mono<OrderResponse> refreshOrder(@PathVariable("id") String id);

        /** POST /api/payments/orders — initier un ordre de paiement */
        @PostExchange("/api/payments/orders")
        Mono<OrderResponse> initiateOrder(@RequestBody InitiateOrderRequest request);

        /** GET /api/payments/orders/{id} — récupérer un ordre */
        @GetExchange("/api/payments/orders/{id}")
        Mono<OrderResponse> getOrder(@PathVariable("id") String id);

        // =========================================================================
        // DTOs — Requêtes
        // =========================================================================

        /**
         * Requête de création de wallet.
         * 
         * @param ownerId   UUID du propriétaire (passager ou chauffeur)
         * @param ownerName Nom complet du propriétaire
         * @param currency  Devise (défaut: XAF pour FCFA)
         */
        record CreateWalletRequest(
                        String ownerId,
                        String ownerName,
                        String currency) {

                /** Constructeur de commodité — devise XAF par défaut (FCFA Cameroun) */
                public CreateWalletRequest(String ownerId, String ownerName) {
                        this(ownerId, ownerName, "XAF");
                }
        }

        /**
         * Requête de paiement depuis le wallet.
         * 
         * @param amount      Montant en FCFA
         * @param description Description de la transaction (ex: "Course Ridngo
         *                    #offerId")
         * @param reference   Référence externe (ex: rideId)
         */
        record PaymentRequest(
                        double amount,
                        String description,
                        String reference) {
        }

        /**
         * Requête d'initiation d'ordre (paiement externe MyCoolPay).
         */
        record InitiateOrderRequest(
                        String reference,
                        double amount,
                        String currency,
                        String description) {
        }

        /**
         * Requête de recharge wallet via provider (MYCOOLPAY).
         * 
         * @param amount         Montant à recharger en FCFA
         * @param payerReference Référence payeur MYCOOLPAY (ex. numéro de téléphone du
         *                       user, format +237...)
         * @param currency       Devise (défaut XAF)
         */
        @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
        record RechargeRequest(
                        double amount,
                        String payerReference,
                        String currency) {

                public RechargeRequest(double amount, String payerReference) {
                        this(amount, payerReference, "XAF");
                }
        }

        // =========================================================================
        // DTOs — Réponses
        // =========================================================================

        @JsonIgnoreProperties(ignoreUnknown = true)
        record WalletResponse(
                        String id,
                        String ownerId,
                        String ownerName,
                        double balance,
                        String currency,
                        String status) {
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        record PaymentResponse(
                        String transactionId,
                        String walletId,
                        double amount,
                        double balanceAfter,
                        String status,
                        String createdAt) {
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        record TransactionResponse(
                        String id,
                        String walletId,
                        double amount,
                        String type,
                        String description,
                        String reference,
                        String createdAt) {
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        record CanOperateResponse(
                        boolean canOperate,
                        String reason) {
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        record RechargeOrderResponse(
                        String orderId,
                        String walletId,
                        double amount,
                        String status,
                        String redirectUrl,
                        String providerReference,
                        String createdAt) {
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        record OrderResponse(
                        String id,
                        String status,
                        double amount,
                        String currency,
                        String paymentUrl,
                        String createdAt) {
        }
}