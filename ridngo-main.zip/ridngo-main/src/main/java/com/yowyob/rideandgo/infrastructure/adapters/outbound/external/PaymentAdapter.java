package com.yowyob.rideandgo.infrastructure.adapters.outbound.external;

import com.yowyob.rideandgo.domain.exception.WalletNotFoundException;
import com.yowyob.rideandgo.domain.model.Wallet;
import com.yowyob.rideandgo.domain.ports.out.PaymentPort;
import com.yowyob.rideandgo.infrastructure.adapters.outbound.external.client.PaymentApiClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import java.util.UUID;

/**
 * Adaptateur vers YowYob Pay (https://kernel-core.yowyob.com/pay).
 * Conforme aux routes YowYob Payment BFF.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentAdapter implements PaymentPort {

        private final PaymentApiClient client;

        /** Taux de commission Ridngo (10% par défaut) */
        private static final double COMMISSION_RATE = 0.10;

        // ─── Wallet ───────────────────────────────────────────────────────────────

        @Override
        public Mono<Wallet> createWallet(UUID ownerId, String ownerName) {
                log.info("💳 [YowYob Pay] Création du wallet pour {} ({})", ownerName, ownerId);
                return client.createWallet(
                                new PaymentApiClient.CreateWalletRequest(ownerId.toString(), ownerName, "XAF"))
                                .map(this::mapToDomain)
                                .onErrorResume(WebClientResponseException.class, ex -> {
                                        log.error("❌ Création wallet échouée pour {}: {} — {}",
                                                        ownerId, ex.getStatusCode(), ex.getResponseBodyAsString());
                                        return Mono.error(new RuntimeException(
                                                        "Impossible de créer le portefeuille YowYob Pay."));
                                });
        }

        @Override
        public Mono<Wallet> getWalletByOwnerId(UUID ownerId) {
                log.info("💳 [YowYob Pay] Récupération wallet pour owner {}", ownerId);
                return client.getWalletByOwnerId(ownerId.toString())
                                .map(this::mapToDomain)
                                .onErrorResume(WebClientResponseException.class, ex -> {
                                        log.error("❌ Wallet introuvable pour owner {}: {} — {}",
                                                        ownerId, ex.getStatusCode(), ex.getResponseBodyAsString());
                                        return Mono.error(new WalletNotFoundException(
                                                        "Votre portefeuille de paiement n'a pas été trouvé. Veuillez contacter le support."));
                                });
        }

        // ─── Paiement ─────────────────────────────────────────────────────────────

        /**
         * Traite le paiement d'une course depuis le wallet du passager.
         * Le montant débité correspond au prix de la course (sans commission pour
         * l'instant —
         * la commission est gérée côté métier via un virement vers le wallet Ridngo).
         *
         * Note: Conformément à la politique "Le prix est un contrat", ce paiement
         * n'est effectué que si le passager dispose d'un wallet crédité.
         * Pour les paiements cash, cette méthode n'est pas appelée.
         */
        @Override
        public Mono<Void> processPayment(UUID walletId, double offerPrice) {
                log.info("💸 [YowYob Pay] Paiement de {} XAF depuis le wallet {}", offerPrice, walletId);
                return client.payFromWallet(
                                walletId.toString(),
                                new PaymentApiClient.PaymentRequest(
                                                offerPrice,
                                                "Course Ridngo — paiement chauffeur",
                                                "RIDE_PAYMENT_" + System.currentTimeMillis()))
                                .doOnSuccess(r -> log.info("✅ Paiement effectué — transaction {}", r.transactionId()))
                                .onErrorResume(WebClientResponseException.class, ex -> {
                                        log.error("❌ Paiement échoué pour wallet {}: {} — {}",
                                                        walletId, ex.getStatusCode(), ex.getResponseBodyAsString());
                                        return Mono.error(new RuntimeException(
                                                        "Échec de la transaction de paiement. Vérifiez votre solde."));
                                })
                                .then();
        }

        // ─── Mapper ───────────────────────────────────────────────────────────────

        // ─── Recharge ─────────────────────────────────────────────────────────────

        @Override
        public Mono<com.yowyob.rideandgo.domain.model.RechargeOrder> rechargeWallet(UUID walletId, double amount,
                        String payerReference) {
                log.info("💰 [YowYob Pay] Recharge de {} XAF pour wallet {} (payerRef={})", amount, walletId,
                                payerReference);
                return client.rechargeWallet(walletId.toString(),
                                new PaymentApiClient.RechargeRequest(amount, payerReference))
                                .map(this::mapRechargeToDomain)
                                .onErrorResume(WebClientResponseException.class, ex -> {
                                        log.error("❌ Recharge échouée pour wallet {}: {} — {}",
                                                        walletId, ex.getStatusCode(), ex.getResponseBodyAsString());
                                        return Mono.error(new RuntimeException(
                                                        "Impossible de démarrer la recharge YowYob Pay."));
                                });
        }

        @Override
        public Mono<com.yowyob.rideandgo.domain.model.RechargeOrder> refreshRechargeOrder(String orderId) {
                log.info("🔄 [YowYob Pay] Rafraîchissement de la recharge {}", orderId);
                return client.refreshRechargeOrder(orderId)
                                .map(this::mapRechargeToDomain)
                                .onErrorResume(WebClientResponseException.class, ex -> {
                                        log.error("❌ Refresh recharge échoué pour {}: {} — {}",
                                                        orderId, ex.getStatusCode(), ex.getResponseBodyAsString());
                                        return Mono.error(new RuntimeException(
                                                        "Impossible de rafraîchir le statut de la recharge."));
                                });
        }

        // ─── Mapper ───────────────────────────────────────────────────────────────

        private com.yowyob.rideandgo.domain.model.RechargeOrder mapRechargeToDomain(
                        PaymentApiClient.RechargeOrderResponse res) {
                return com.yowyob.rideandgo.domain.model.RechargeOrder.builder()
                                .orderId(res.orderId())
                                .walletId(res.walletId())
                                .amount(res.amount())
                                .status(res.status())
                                .redirectUrl(res.redirectUrl())
                                .build();
        }

        private Wallet mapToDomain(PaymentApiClient.WalletResponse res) {
                return Wallet.builder()
                                .id(res.id() != null ? UUID.fromString(res.id()) : UUID.randomUUID())
                                .ownerId(res.ownerId() != null ? UUID.fromString(res.ownerId()) : UUID.randomUUID())
                                .ownerName(res.ownerName() != null ? res.ownerName() : "Inconnu")
                                .balance(res.balance())
                                .build();
        }
}