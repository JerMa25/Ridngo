package com.yowyob.rideandgo.infrastructure.adapters.inbound.rest;

import com.yowyob.rideandgo.domain.model.RechargeOrder;
import com.yowyob.rideandgo.domain.model.Wallet;
import com.yowyob.rideandgo.domain.ports.out.PaymentPort;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/wallets")
@RequiredArgsConstructor
@Tag(name = "Payment-Wallet", description = "Driver balance and transaction management")
public class WalletController {
    private final PaymentPort paymentPort;

    @GetMapping("/me")
    @Operation(summary = "Get My Wallet", description = "Retrieve balance for the current authenticated driver.")
    @PreAuthorize("hasAuthority('RIDE_AND_GO_DRIVER')")
    public Mono<Wallet> getMyWallet() {
        return getCurrentUserId().flatMap(paymentPort::getWalletByOwnerId);
    }

    @PostMapping("/me/recharge")
    @Operation(summary = "Recharge My Wallet", description = "Démarre une recharge via le provider externe (MYCOOLPAY). Renvoie une redirectUrl à ouvrir côté client.")
    @PreAuthorize("hasAuthority('RIDE_AND_GO_DRIVER')")
    public Mono<RechargeOrder> rechargeMyWallet(@RequestBody RechargeRequestDto request) {
        return getCurrentUserId()
                .flatMap(paymentPort::getWalletByOwnerId)
                .flatMap(wallet -> paymentPort.rechargeWallet(wallet.id(), request.amount(), request.payerReference()));
    }

    @PostMapping("/recharge-orders/{orderId}/refresh")
    @Operation(summary = "Refresh Recharge Order", description = "À appeler après le retour du provider (MYCOOLPAY) pour confirmer et créditer le wallet.")
    @PreAuthorize("hasAuthority('RIDE_AND_GO_DRIVER')")
    public Mono<RechargeOrder> refreshRecharge(@PathVariable String orderId) {
        return paymentPort.refreshRechargeOrder(orderId);
    }

    private Mono<UUID> getCurrentUserId() {
        return ReactiveSecurityContextHolder.getContext()
                .map(SecurityContext::getAuthentication)
                .map(auth -> UUID.fromString(auth.getName()));
    }

    public record RechargeRequestDto(double amount, String payerReference) {
    }
}